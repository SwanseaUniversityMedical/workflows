/*! licenses: /vendor.LICENSE.txt */
import{j as t,a7 as e,aq as i,M as s}from"./echoes-D3doNxvb.js";function r({className:a}){return t.jsx(e,{className:a,variety:i.Neutral,"data-component":"built-in-quality-gate-badge",children:t.jsx(s,{id:"quality_gates.built_in"})})}export{r as B};
//# sourceMappingURL=BuiltInQualityGateBadge-C7jj2ik8.js.map
