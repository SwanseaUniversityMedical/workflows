/*! licenses: /vendor.LICENSE.txt */
import{j as a}from"./echoes-CwOitFSX.js";import"./vendor-C8omvz16.js";import{dT as i,ad as e}from"./main-CvG1T1Bn.js";function s({className:t}){return a.jsx(i,{className:t,"data-component":"built-in-quality-gate-badge",children:e("quality_gates.built_in")})}export{s as B};
//# sourceMappingURL=BuiltInQualityGateBadge-Dx46MJdG.js.map
