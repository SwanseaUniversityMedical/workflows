/*! licenses: /vendor.LICENSE.txt */
import{j as i}from"./echoes-CwOitFSX.js";import"./vendor-C8omvz16.js";import{dT as n,ad as r,aT as o}from"./main-CvG1T1Bn.js";function d({className:a,tooltip:e=!0}){const t=i.jsx(n,{className:a,variant:"default",children:r("quality_profiles.built_in")});return e?i.jsx(o,{content:r("quality_profiles.built_in.description"),children:t}):t}export{d as B};
//# sourceMappingURL=BuiltInQualityProfileBadge-Ci7kz6Uh.js.map
