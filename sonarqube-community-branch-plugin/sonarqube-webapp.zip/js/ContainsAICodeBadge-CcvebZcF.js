/*! licenses: /vendor.LICENSE.txt */
import{j as a,a6 as s,b7 as t,M as r}from"./echoes-CwOitFSX.js";import{a as i}from"./vendor-C8omvz16.js";const d=i.forwardRef((e,o)=>a.jsx(s,{...e,IconLeft:t,ref:o,variety:"highlight",children:a.jsx(r,{id:"contains_ai_code"})}));d.displayName="ContainsAICodeBadge";export{d as C};
//# sourceMappingURL=ContainsAICodeBadge-CcvebZcF.js.map
