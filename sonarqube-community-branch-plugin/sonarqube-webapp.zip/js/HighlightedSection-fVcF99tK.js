/*! licenses: /vendor.LICENSE.txt */
import{c as e,b as r,t as o}from"./main-CvG1T1Bn.js";const t=e("div",{target:"e1jj8g8f0"})("border:",r("default","highlightedSectionBorder"),";background:",o("highlightedSection"),";",{boxSizing:"border-box"}," ",{display:"flex",flexDirection:"column"}," ",{gap:"1rem"}," ",{padding:"2rem"}," ",{borderRadius:"0.5rem"},";");export{t as H};
//# sourceMappingURL=HighlightedSection-fVcF99tK.js.map
