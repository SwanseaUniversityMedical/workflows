/*! licenses: /vendor.LICENSE.txt */
import{j as e,D as r,M as t}from"./echoes-D3doNxvb.js";import"./vendor-CosJKDqA.js";import"./main-D-mxIHy_.js";import{R as s}from"./RequiredIcon-C9rGsjOo.js";function m({className:a}){return e.jsx(r,{"aria-hidden":!0,className:a,isSubtle:!0,"data-component":"mandatory-fields-explanation",children:e.jsx(t,{id:"fields_marked_with_x_required",values:{star:e.jsx(s,{className:"sw-m-0"})}})})}export{m as M};
//# sourceMappingURL=MandatoryFieldsExplanation-BisM96gw.js.map
