/*! licenses: /vendor.LICENSE.txt */
import{aT as n,ad as i,d as r}from"./main-CvG1T1Bn.js";import{j as t}from"./echoes-CwOitFSX.js";function d({className:e,qualifier:s,visibility:a}){return t.jsx(n,{content:i("visibility",a,"description",s),"data-component":"privacy-badge-container",children:t.jsx("div",{className:r("badge",e),children:i("visibility",a)})})}export{d as P};
//# sourceMappingURL=PrivacyBadgeContainer-B9H5coEh.js.map
