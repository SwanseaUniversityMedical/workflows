/*! licenses: /vendor.LICENSE.txt */
import{aT as n,af as i,d as r}from"./main-D-mxIHy_.js";import{j as t}from"./echoes-D3doNxvb.js";function d({className:e,qualifier:s,visibility:a}){return t.jsx(n,{content:i("visibility",a,"description",s),"data-component":"privacy-badge-container",children:t.jsx("div",{className:r("badge",e),children:i("visibility",a)})})}export{d as P};
//# sourceMappingURL=PrivacyBadgeContainer-C9t02SKD.js.map
