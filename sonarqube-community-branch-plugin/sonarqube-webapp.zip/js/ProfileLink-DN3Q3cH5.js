/*! licenses: /vendor.LICENSE.txt */
import{j as n}from"./echoes-CwOitFSX.js";import"./vendor-C8omvz16.js";import{av as a,kp as e}from"./main-CvG1T1Bn.js";function f({name:o,language:t,children:r,...i}){return n.jsx(a,{to:e(o,t),...i,"data-component":"profile-link",children:r})}export{f as P};
//# sourceMappingURL=ProfileLink-DN3Q3cH5.js.map
