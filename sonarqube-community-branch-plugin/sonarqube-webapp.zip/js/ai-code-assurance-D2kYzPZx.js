/*! licenses: /vendor.LICENSE.txt */
import{al as o,am as s}from"./main-D-mxIHy_.js";import{g as n,c as y,d}from"./AIAssuredIcon-CdexEPCE.js";const a="project-ai-code-assurance",_=o(({project:e,branch:t})=>s({queryKey:[a,e.key,"code-assurance","branch",t],queryFn:({queryKey:[r,u,i,A,c]})=>y(u,c)})),j=o(({project:e})=>s({queryKey:[a,e.key,"containsAiCode"],queryFn:({queryKey:[t,r]})=>n(r)})),P=o(({project:e})=>s({queryKey:[a,e.key,"detectedAiCode"],queryFn:({queryKey:[t,r]})=>d(r)}));export{P as a,j as b,_ as u};
//# sourceMappingURL=ai-code-assurance-D2kYzPZx.js.map
