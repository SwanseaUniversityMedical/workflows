/*! licenses: /vendor.LICENSE.txt */
import{ai as e,ah as p,ag as o,b3 as c}from"./main-CvG1T1Bn.js";function r(a,t){return e("/api/applications/show_leak",{application:a,branch:t}).then(i=>i.leaks,p)}function l(a,t){return e("/api/applications/show",{application:a,branch:t}).then(i=>i.application,p)}function h(a,t,i,n){return c("/api/applications/create",{description:t,key:i,name:a,visibility:n}).catch(p)}function u(a){return o("/api/applications/delete",{application:a}).catch(p)}export{r as a,h as c,u as d,l as g};
//# sourceMappingURL=application-BO41dFWf.js.map
