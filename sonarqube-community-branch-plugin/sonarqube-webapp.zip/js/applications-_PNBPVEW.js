/*! licenses: /vendor.LICENSE.txt */
import{aj as n,ak as o,al as i,am as s,i6 as u}from"./main-CvG1T1Bn.js";import{a as r,d as p}from"./application-BO41dFWf.js";const y=n(e=>o({queryKey:["application","leak",e],queryFn:()=>r(e)}));function m(){const e=i();return s({mutationFn:a=>p(a),onSuccess:(a,t)=>{u(t,e)}})}export{m as a,y as u};
//# sourceMappingURL=applications-_PNBPVEW.js.map
