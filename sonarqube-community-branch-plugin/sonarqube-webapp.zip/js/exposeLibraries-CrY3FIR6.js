/*! licenses: /vendor.LICENSE.txt */
import{bN as s,ah as t,eo as o,b3 as r,ag as e,co as i,bA as p,kY as l,ai as m,cl as b,c7 as c,ad as d,aS as g}from"./main-CvG1T1Bn.js";import"./vendor-C8omvz16.js";import"./echoes-CwOitFSX.js";import"./lodash-CMuwmbNm.js";import"./highlightjs-BXzlIbdZ.js";import"./datefns-CwRd61Cc.js";const x=()=>{const a=window;a.SonarRequest={request:c,get:b,getJSON:m,getText:l,omitNil:p,parseError:i,post:e,postJSON:r,postJSONBody:o,throwGlobalError:t,addGlobalSuccessMessage:s},a.t=d,a.tp=g};export{x as default};
//# sourceMappingURL=exposeLibraries-CrY3FIR6.js.map
