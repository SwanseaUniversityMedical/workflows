/*! licenses: /vendor.LICENSE.txt */
import{E as e}from"./echoes-CwOitFSX.js";import{co as s}from"./main-CvG1T1Bn.js";function n(r){return r instanceof Response?s(r).then(o=>{e.error({description:o,duration:"short"})},()=>{}):typeof r=="string"?Promise.resolve(r).then(o=>{e.error({description:o,duration:"short"})}):Promise.resolve()}export{n as a};
//# sourceMappingURL=globalMessages-BWP7k9I0.js.map
