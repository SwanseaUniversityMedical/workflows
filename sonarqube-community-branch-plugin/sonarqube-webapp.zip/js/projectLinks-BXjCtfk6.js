/*! licenses: /vendor.LICENSE.txt */
import{ak as n,aj as r,b2 as a,ai as i}from"./main-D-mxIHy_.js";function s(t){return n("/api/project_links/search",{projectKey:t}).then(e=>e.links,r)}function c(t){return i("/api/project_links/delete",{id:t}).catch(r)}function p(t){return a("/api/project_links/create",t).then(e=>e.link,r)}export{p as c,c as d,s as g};
//# sourceMappingURL=projectLinks-BXjCtfk6.js.map
