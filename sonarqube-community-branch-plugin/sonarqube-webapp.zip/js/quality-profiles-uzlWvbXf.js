/*! licenses: /vendor.LICENSE.txt */
let E=function(D){return D.MQR="MQR",D.STANDARD="STANDARD",D}({}),T=function(D){return D.Activated="ACTIVATED",D.Deactivated="DEACTIVATED",D.Updated="UPDATED",D}({}),t=function(D){return D.Copy="COPY",D.Extend="EXTEND",D.Rename="RENAME",D.Delete="DELETE",D}({});export{T as C,t as P,E as Q};
//# sourceMappingURL=quality-profiles-uzlWvbXf.js.map
