/*! licenses: /vendor.LICENSE.txt */
import{az as s}from"./main-CvG1T1Bn.js";import{j as n}from"./echoes-CwOitFSX.js";import{s as e}from"./vendor-C8omvz16.js";function p(t){function o(i){const r=e();return n.jsx(t,{...i,...r,"data-component":"component-with-quality-profiles-props"})}return o.displayName=s(t,"withQualityProfilesContext"),o}function f(){return e()}export{f as u,p as w};
//# sourceMappingURL=qualityProfilesContext-LNeoT49Q.js.map
