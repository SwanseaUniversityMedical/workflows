/*! licenses: /vendor.LICENSE.txt */
let a=function(o){return o.Default="default",o.Introduction="introduction",o.RootCause="root_cause",o.AssessTheProblem="assess_the_problem",o.HowToFix="how_to_fix",o.Resources="resources",o}({});const s=["BUG","VULNERABILITY","CODE_SMELL","SECURITY_HOTSPOT","VIOLATION","UNKNOWN"];export{a as R,s as a};
//# sourceMappingURL=rules-CXW0kjnh.js.map
