/*! licenses: /vendor.LICENSE.txt */
import{cl as u,jz as s,aj as t,ak as o}from"./main-CvG1T1Bn.js";function n(e){return u("/api/sources/raw",e).then(s)}const a=6e4;function c(e,r){return["sources","details",e,r]}const i=t(e=>o({queryKey:c(e.key,e),queryFn:()=>n(e),staleTime:a}));export{i as u};
//# sourceMappingURL=sources-CK_WLtWq.js.map
