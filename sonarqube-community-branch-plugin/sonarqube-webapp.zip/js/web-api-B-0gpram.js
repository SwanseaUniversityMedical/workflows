/*! licenses: /vendor.LICENSE.txt */
import{ai as t,ah as a}from"./main-CvG1T1Bn.js";function n(e=!0){return t("/api/webservices/list",{include_internals:e}).then(r=>r.webServices).catch(a)}function s(e,r){return t("/api/webservices/response_example",{controller:e,action:r}).catch(a)}function i(){return t("/api/v2/api-docs").catch(a)}export{i as a,s as b,n as f};
//# sourceMappingURL=web-api-B-0gpram.js.map
