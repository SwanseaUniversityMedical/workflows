/*! licenses: /vendor.LICENSE.txt */
import{b4 as e}from"./main-CvG1T1Bn.js";import{f as r,a as n}from"./web-api-B-0gpram.js";function t(){return e({queryKey:["web-api"],queryFn:()=>r(!1)})}const a=()=>e({queryKey:["open_api"],queryFn:n,staleTime:1/0,gcTime:1/0});export{a,t as u};
//# sourceMappingURL=web-api-BA2AaNpG.js.map
