/*! licenses: /vendor.LICENSE.txt */
import{e as o,j as r}from"./echoes-CwOitFSX.js";function h(e){return function(t){const n=o();return r.jsx(e,{theme:n,...t})}}export{h as w};
//# sourceMappingURL=withTheme-DB1JWTRJ.js.map
