/*! licenses: /vendor.LICENSE.txt */
import{j as i}from"./echoes-D3doNxvb.js";import"./vendor-CosJKDqA.js";import{dR as n,af as r,aT as o}from"./main-D-mxIHy_.js";function f({className:a,tooltip:e=!0}){const t=i.jsx(n,{className:a,variant:"default",children:r("quality_profiles.built_in")});return e?i.jsx(o,{content:r("quality_profiles.built_in.description"),children:t}):t}export{f as B};
//# sourceMappingURL=BuiltInQualityProfileBadge-yulpkCY4.js.map
