/*! licenses: /vendor.LICENSE.txt */
import{j as n}from"./echoes-D3doNxvb.js";import"./vendor-CosJKDqA.js";import{cg as a,k1 as e}from"./main-D-mxIHy_.js";function f({name:o,language:t,children:r,...i}){return n.jsx(a,{to:e(o,t),...i,"data-component":"profile-link",children:r})}export{f as P};
//# sourceMappingURL=ProfileLink-BRkptIOH.js.map
