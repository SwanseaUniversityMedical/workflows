/*! licenses: /vendor.LICENSE.txt */
import{c as o}from"./main-D-mxIHy_.js";import{j as r,t as e}from"./echoes-D3doNxvb.js";function c(t){return r.jsx(n,{...t,"data-component":"required-icon",children:"*"})}const n=o("span",{target:"e1se3pf80"})("color:",e("color-text-danger"),";font:",e("typography-others-label-medium"),";margin-left:",e("dimension-space-25"),";");export{c as R};
//# sourceMappingURL=RequiredIcon-C9rGsjOo.js.map
