/*! licenses: /vendor.LICENSE.txt */
import{bM as s,aj as t,el as o,b2 as r,ai as e,cp as p,bA as i,kw as l,ak as m,cm as b,c4 as c,af as n,aS as S}from"./main-D-mxIHy_.js";import"./vendor-CosJKDqA.js";import"./echoes-D3doNxvb.js";import"./lodash-DZXqzBor.js";import"./highlightjs-CFvgWmRf.js";import"./datefns-GSH1D4xx.js";const x=()=>{const a=window;a.SonarRequest={request:c,get:b,getJSON:m,getText:l,omitNil:i,parseError:p,post:e,postJSON:r,postJSONBody:o,throwGlobalError:t,addGlobalSuccessMessage:s},a.t=n,a.tp=S};export{x as default};
//# sourceMappingURL=exposeLibraries-BFgfpE7w.js.map
