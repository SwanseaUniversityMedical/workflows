/*! licenses: /vendor.LICENSE.txt */
import{B as e}from"./echoes-D3doNxvb.js";import{cp as s}from"./main-D-mxIHy_.js";function n(r){return r instanceof Response?s(r).then(o=>{e.error({description:o,duration:"short"})},()=>{}):typeof r=="string"?Promise.resolve(r).then(o=>{e.error({description:o,duration:"short"})}):Promise.resolve()}export{n as a};
//# sourceMappingURL=globalMessages-DMkW69LL.js.map
