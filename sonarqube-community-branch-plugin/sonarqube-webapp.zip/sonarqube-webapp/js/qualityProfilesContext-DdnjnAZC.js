/*! licenses: /vendor.LICENSE.txt */
import{aA as n}from"./main-D-mxIHy_.js";import{j as s}from"./echoes-D3doNxvb.js";import{v as e}from"./vendor-CosJKDqA.js";function p(t){function o(i){const r=e();return s.jsx(t,{...i,...r,"data-component":"component-with-quality-profiles-props"})}return o.displayName=n(t,"withQualityProfilesContext"),o}function f(){return e()}export{f as u,p as w};
//# sourceMappingURL=qualityProfilesContext-DdnjnAZC.js.map
