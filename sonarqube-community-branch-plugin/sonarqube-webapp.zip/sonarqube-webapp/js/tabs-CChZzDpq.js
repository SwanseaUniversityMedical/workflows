/*! licenses: /vendor.LICENSE.txt */
function t(a){return"tabpanel-".concat(a)}function n(a){return"tab-".concat(a)}export{t as a,n as g};
//# sourceMappingURL=tabs-CChZzDpq.js.map
