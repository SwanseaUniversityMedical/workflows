/*! licenses: /vendor.LICENSE.txt */
import{ak as t,aj as a}from"./main-D-mxIHy_.js";function n(e=!0){return t("/api/webservices/list",{include_internals:e}).then(r=>r.webServices).catch(a)}function s(e,r){return t("/api/webservices/response_example",{controller:e,action:r}).catch(a)}function i(){return t("/api/v2/api-docs").catch(a)}export{i as a,s as b,n as f};
//# sourceMappingURL=web-api-CYLi2EC8.js.map
