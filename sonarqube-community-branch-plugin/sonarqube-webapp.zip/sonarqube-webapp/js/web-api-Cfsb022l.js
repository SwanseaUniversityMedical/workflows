/*! licenses: /vendor.LICENSE.txt */
import{b3 as e}from"./main-D-mxIHy_.js";import{f as r,a as n}from"./web-api-CYLi2EC8.js";function t(){return e({queryKey:["web-api"],queryFn:()=>r(!1)})}const a=()=>e({queryKey:["open_api"],queryFn:n,staleTime:1/0,gcTime:1/0});export{a,t as u};
//# sourceMappingURL=web-api-Cfsb022l.js.map
